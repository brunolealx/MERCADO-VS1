package com.creativex.ui.clientes;

import javax.swing.*;
import java.awt.*;

public class ClientesForm extends JPanel {
    public ClientesForm() {
        setLayout(new BorderLayout());
        add(new JLabel("👥 Módulo Clientes — Em desenvolvimento", SwingConstants.CENTER), BorderLayout.CENTER);
    }
}
