package com.creativex.ui.estoque;

import javax.swing.*;
import java.awt.*;

public class EstoqueForm extends JPanel {
    public EstoqueForm() {
        setLayout(new BorderLayout());
        add(new JLabel("📊 Módulo Estoque — Em desenvolvimento", SwingConstants.CENTER), BorderLayout.CENTER);
    }
}
