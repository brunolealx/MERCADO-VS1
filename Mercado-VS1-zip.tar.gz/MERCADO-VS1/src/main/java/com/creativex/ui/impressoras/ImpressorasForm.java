package com.creativex.ui.impressoras;

import javax.swing.*;
import java.awt.*;

public class ImpressorasForm extends JPanel {
    public ImpressorasForm() {
        setLayout(new BorderLayout());
        add(new JLabel(" Módulo Impressoras  — Em desenvolvimento", SwingConstants.CENTER), BorderLayout.CENTER);
    }
}


