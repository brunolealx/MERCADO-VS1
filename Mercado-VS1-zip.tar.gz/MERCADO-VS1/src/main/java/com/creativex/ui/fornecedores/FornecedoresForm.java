package com.creativex.ui.fornecedores;

import javax.swing.*;
import java.awt.*;

public class FornecedoresForm extends JPanel {
    public FornecedoresForm() {
        setLayout(new BorderLayout());
        add(new JLabel("🏭 Módulo Fornecedores — Em desenvolvimento", SwingConstants.CENTER), BorderLayout.CENTER);
    }
}


