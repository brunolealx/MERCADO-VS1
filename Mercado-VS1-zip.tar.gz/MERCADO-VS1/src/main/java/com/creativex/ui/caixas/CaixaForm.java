package com.creativex.ui.caixas;
import javax.swing.*;
import java.awt.*;

public class CaixaForm extends JPanel {
    public CaixaForm() {
        setLayout(new BorderLayout());
        add(new JLabel("💵 Módulo Caixas — Em desenvolvimento", SwingConstants.CENTER), BorderLayout.CENTER);
    }
}
