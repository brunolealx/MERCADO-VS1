package com.creativex;
import com.creativex.ui.MainWindow;
import com.creativex.ui.login.LoginForm;

public class Main {
    public static void main(String[] args) {
  //      javax.swing.SwingUtilities.invokeLater(() -> new LoginForm().setVisible(true));
        new MainWindow().setVisible(true);
    }
}
